﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MyChallange4
{
    public partial class Defualt : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void purchaseButton_Click(object sender, EventArgs e)
        {
            double total = 0;

            if (sizeButton1.Checked)
                total = 10.00;
            else if (sizeButton2.Checked)
                total = 13.00;
            else if (sizeButton3.Checked)
                total = 16.00;


            if (crustButton2.Checked)
                total += 2.00;


            if (toppingButton1.Checked)
                total += 1.50;

            if (toppingButton2.Checked)
                total += .75;

            if (toppingButton3.Checked)
                total += .50;

            if (toppingButton4.Checked)
                total += .50;

            if (toppingButton5.Checked)
                total += 2.00;

            if (toppingButton1.Checked
                && toppingButton3.Checked
                && toppingButton5.Checked)
                total -= 2.00;

            else if (toppingButton1.Checked
                && toppingButton2.Checked
                && toppingButton4.Checked)
                total -= 2.00;


                string resultTotal = Convert.ToString(total);

            resultLabel.Text = "Your Total will be $" + resultTotal;




        }
    }
}